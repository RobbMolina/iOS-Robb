//
//  Star_warsApp.swift
//  Star wars
//
//  Created by WIN603 on 15/08/25.
//

import SwiftUI

@main
struct Star_warsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
